class Solution:
    def busyStudent(self, startTime: list[int], endTime: list[int], queryTime: int) -> int:
        count = 0
        # Iterate through every student
        for i in range(len(startTime)):
            # Check if queryTime is inside the interval [start, end]
            if startTime[i] <= queryTime <= endTime[i]:
                count += 1
        return count