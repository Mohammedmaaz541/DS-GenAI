class Solution:
    def countBits(self, n: int) -> list[int]:
        ans = []
        for i in range(n + 1):
            # bin(i) returns string like '0b101', count('1') counts the ones
            ans.append(bin(i).count('1'))
        return ans