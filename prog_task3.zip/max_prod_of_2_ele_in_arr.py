class Solution:
    def maxProduct(self, nums: list[int]) -> int:
        max1 = 0
        max2 = 0
        
        for num in nums:
            if num > max1:
                # Current number is the new largest
                # The previous largest (max1) now becomes second largest (max2)
                max2 = max1
                max1 = num
            elif num > max2:
                # Current number isn't the largest, but is larger than the second largest
                max2 = num
                
        return (max1 - 1) * (max2 - 1)