class Solution:
    def smallerNumbersThanCurrent(self, nums: list[int]) -> list[int]:
        count = [0] * 102
        
        # Count frequency of each number
        for num in nums:
            count[num + 1] += 1
            
        # Accumulate counts (prefix sum)
        for i in range(1, 102):
            count[i] += count[i - 1]
            
        return [count[num] for num in nums]