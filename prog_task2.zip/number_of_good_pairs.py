class Solution:
    def numIdenticalPairs(self, nums: list[int]) -> int:
        count = 0
        seen = {}  # Dictionary to store frequency: {number: count}
        
        for num in nums:
            # If num is already in our map, it forms pairs with all previous instances
            if num in seen:
                count += seen[num]
                seen[num] += 1
            else:
                seen[num] = 1
                
        return count