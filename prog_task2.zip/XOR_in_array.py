class Solution:
    def xorOperation(self, n: int, start: int) -> int:
        result = 0
        for i in range(n):
            # Calculate the current number
            num = start + 2 * i
            # Apply bitwise XOR
            result = result ^ num
        return result