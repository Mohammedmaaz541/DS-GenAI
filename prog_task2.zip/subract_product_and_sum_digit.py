class Solution:
    def subtractProductAndSum(self, n: int) -> int:
        s = str(n)
        product_of_digits = 1
        sum_of_digits = 0
        
        for char in s:
            digit = int(char)
            product_of_digits *= digit
            sum_of_digits += digit
            
        return product_of_digits - sum_of_digits